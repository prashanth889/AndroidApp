function getAuthorizeUrlSyncData(loginUrl, clientId, redirectUri){
         return loginUrl+'services/oauth2/authorize?display=touch'
             +'&response_type=token&client_id='+escape(clientId)
             +'&redirect_uri='+escape(redirectUri);
     }

     function sessionCallbackSyncData(loc) {
         var oauthResponse = {};

         var fragment = loc.split("#")[1];

         if (fragment) {
             var nvps = fragment.split('&');
             for (var nvp in nvps) {
                 var parts = nvps[nvp].split('=');
                 oauthResponse[parts[0]] = unescape(parts[1]);
             }
         }

         if (typeof oauthResponse === 'undefined'
             || typeof oauthResponse['access_token'] === 'undefined') {
             alert("Unauthorized: No OAuth response");
         } else {
             client.setSessionToken(oauthResponse.access_token, null,
                 oauthResponse.instance_url);
            client.createJob({
         	    operation : 'insert',
         	    object : 'Universities__c',
         	    contentType : 'CSV'
         	}, function(response) {
         	    jobId = response.jobInfo.id;
         	    console.log('Job created with id '+jobId+'\n');
         	    var csvData = "Name,Description__c\n"+
               "Tom,'Self-described as branding guru on the West Coast\n"+
               "Ian,'World-renowned expert in fuzzy logic design. Influential in technology purchases.'\n";
         	    client.addBatch(jobId, "text/csv; charset=UTF-8", csvData, function(response){
              	   batchId = response.batchInfo.id;
              	    console.log('Batch state: ',response.batchInfo.state+'\n');
              	   client.closeJob(jobId, function(response){
                	    console.log('Job closed. State: '+response.jobInfo.state+'\n');
                	   client.getBatchDetails(jobId, batchId, function(response){
              	    console.log('Batch state: '+response.batchInfo.state+'\n');
              	   client.getBatchResult(jobId, batchId, false, function(response){
                	    console.log('Batch result: '+response);
                	});
              	});
                	});
              	    
              	});
         	});
            
          /*  var csvData = "FirstName,LastName,Department,Birthdate,Description\n"+
            "Tom,Jones,Marketing,1940-06-07Z,'Self-described as branding guru on the West Coast\n"+
            "Ian,Dury,R&D,,'World-renowned expert in fuzzy logic design. Influential in technology purchases.'\n";*/
            
       
         }
     }