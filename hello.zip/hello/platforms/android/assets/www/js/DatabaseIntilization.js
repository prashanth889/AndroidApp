var db; 
var len;

function getDb()
{
    if (db === undefined || db == null) {
        db = window.sqlitePlugin.openDatabase({ name: "IDP.db", location: 'default'});
    }
}

// initializing Database
function initializeDB() {
    // var db = window.openDatabase("MCRMDB", "1.0", "MCRMDB", 1000000);
	alert("hi");
	var db = window.sqlitePlugin.openDatabase({name: "IDP.db", location: 'default'});
     db.transaction(checkIfDBCreated);
 	
 	function checkIfDBCreated(tx){
 		 //var data = tx.executeSql("SELECT count(*) FROM Users", []);
 		 //console.log("data"+data);
 		
 		tx.executeSql('CREATE TABLE IF NOT EXISTS Users (contact_id text,first_name text,last_name text,email text ,phone text)', [], function(rs) {
  		    console.log('Record count (expected to be 2): ' + rs);
  		    db.transaction(function(tx){
  		    	tx.executeSql("SELECT Count(*) FROM Users", [], function(tx, results) {
  		    		 len = results.rows.length;
  	 	  		    console.log('Record count: ' + len);
  	 			  }, function(error) {
  	 			    console.log('SELECT SQL statement ERROR: ' + error.message);
  	 			  });
  		    });
		  }, function(error) {
		    console.log('SELECT SQL statement ERROR: ' + error.message);
		  });	 
 	}
 	return len;
}

/*function insertDataIntoDatabase(recordsData){
	
	console.log("database"+recordsData);
}*/


function insertDataIntoDatabase(companyData ){
	getDb();   
    console.log('query starting');
       db.transaction(function (tx) {
         var thesql = 'INSERT INTO Users ' +
              '( ' +
              'contact_id,' +
              'first_name,' +
              'last_name,' +
              'email,'+
              'phone'+
              ') VALUES ';
         /*for (var i = 0; i < companyData.records.length; i++){
              thesql = thesql +
                   '(' +
                   '?,' +
                   '?,' +
                   'null,' +
                   'null,' +
                   'null)';
                   
                   // add comma after each set of values except last
                   if (i < 499 ){
                        thesql = thesql + ',';
                    }
               }*/
               //Add all values into parameter array
               var paramArray = [];
               for ( i = 0; i < companyData.records.length; i++){
                   //paramArray.push( companyData.records[i].Id);
                  // paramArray.push( companyData.records[i].Name);
                   thesql = thesql +
                   '(' +'"'+companyData.records[i].Id+'"' +','+'"'+companyData.records[i].Name+'"'+','+'"null",'+'"null",'+'"null")';
                   
                   // add comma after each set of values except last
                   if (i < companyData.records.length-1 ){
                        thesql = thesql + ',';
                    }
                   //paramArray.push( companyData[i].Description__c );
                   //paramArray.push( companyData[i].updatedAt );
                   //paramArray.push( companyData[i].datetimestampticks );
                  // paramArray.push( localTimeStamp );
               }
               //execute the query
               tx.executeSql(thesql,paramArray,function(result){
            	              console.log(result);
            	              queryData();
               },function(error){
            	            console.log(error.message);
               });
    });
}

function queryData(){
	getDb();
    db.transaction(queryStudentDetails);
	function queryStudentDetails(tx){
		    	tx.executeSql("SELECT * FROM Users", [], function(tx, results) {
		    		var querylen = results.rows.length;
		    		for (var i = 0; i < results.rows.length; i++) {
		    	          var row = results.rows.item(i);
		    	          var $row = $('<tr>'+
		    	        	      '<td>'+row.first_name+'</td>'+
		    	        	      '</tr>');
		    	          $('#detailsId').append($row);
		    	        }
	 	  		    console.log('querylen: ' + querylen);
	 			  }, function(error) {
	 			    console.log('SELECT SQL statement ERROR: ' + error.message);
	 			  });
	}
}


